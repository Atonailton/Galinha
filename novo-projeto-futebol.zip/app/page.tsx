'use client';

import { useState } from 'react';

export default function Home() {
  const [team, setTeam] = useState('');
  const [result, setResult] = useState<any>(null);

  async function search() {
    const res = await fetch(`https://api-football-v1.p.rapidapi.com/v3/fixtures?live=all`, {
      method: "GET",
      headers: {
        "X-RapidAPI-Key": "6014d15aeb21559553781a2f2fd6e18a",
        "X-RapidAPI-Host": "api-football-v1.p.rapidapi.com"
      }
    });

    const data = await res.json();
    const match = data.response.find((item: any) =>
      item.teams.home.name.toLowerCase().includes(team.toLowerCase()) ||
      item.teams.away.name.toLowerCase().includes(team.toLowerCase())
    );

    if (match) {
      setResult({
        home: match.teams.home.name,
        away: match.teams.away.name,
        goals: match.goals,
        firstGoal: match.goals?.[0]?.player?.name || "Não disponível"
      });
    } else {
      setResult("Não encontrado");
    }
  }

  return (
    <main style={{ padding: 20 }}>
      <h1>Placar ao Vivo</h1>
      <input
        type="text"
        placeholder="Digite o nome do time"
        value={team}
        onChange={(e) => setTeam(e.target.value)}
      />
      <button onClick={search}>Buscar</button>
      {result && typeof result === 'object' && (
        <div>
          <h2>{result.home} vs {result.away}</h2>
          <p>Gols: {JSON.stringify(result.goals)}</p>
          <p>Primeiro Gol: {result.firstGoal}</p>
        </div>
      )}
      {result && typeof result === 'string' && <p>{result}</p>}
    </main>
  );
}
