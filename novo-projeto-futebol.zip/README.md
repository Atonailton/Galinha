# Novo Projeto Futebol

Aplicação que busca partidas ao vivo, placares por tempo e o autor do primeiro gol usando a API Football.

## Como usar

1. `npm install`
2. `npm run dev`

Ou suba direto no Vercel com esta estrutura.
